package edu.alb;

import java.util.Collection;

public abstract class SemiGroup<T> {
	public abstract T operate(T a, T b);
	
	public static <T> T combine(Collection<T> list){
		return null;
	}
}
