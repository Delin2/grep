package edu.alb;

public class PositiveInteger extends SemiGroup<Integer> {

	@Override
	public Integer operate(Integer a, Integer b) {
		
		return a + b;
	}

}
