package edu.alb;

import java.util.BitSet;

public class BinaryWord implements Complementable<BitSet>{


}
