package edu.alb;

public interface Complementable<T> {
	T complement();
}
